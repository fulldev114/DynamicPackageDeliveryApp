//
//  ABCRadio.h
//  your-dpd
//
//  Created by Richard Simkins on 15/05/2015.
//  Copyright (c) 2015 dpd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ABCRadio : UIView
	- (CGFloat) SizeView;

	- (BOOL) isSelected;
	- (void) setSelected:(BOOL)selected;
@end
