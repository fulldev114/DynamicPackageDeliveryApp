//
//  ABCDeliverSafePlaceAlertAccept.h
//  your-dpd
//
//  Created by Richard Simkins on 26/05/2015.
//  Copyright (c) 2015 dpd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ABCAlert.h"

@interface ABCDeliverSafePlaceAlertAccept : ABCAlert
@end
