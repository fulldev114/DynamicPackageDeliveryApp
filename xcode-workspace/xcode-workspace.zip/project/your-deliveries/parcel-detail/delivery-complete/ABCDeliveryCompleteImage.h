//
//  ABCDeliveryCompleteImage.h
//  your-dpd
//
//  Created by Richard Simkins on 22/05/2015.
//  Copyright (c) 2015 dpd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ABCDeliveryCompleteImage : UIView
	- (instancetype) initWithParentHeight:(CGFloat)parentHeight;
@end
