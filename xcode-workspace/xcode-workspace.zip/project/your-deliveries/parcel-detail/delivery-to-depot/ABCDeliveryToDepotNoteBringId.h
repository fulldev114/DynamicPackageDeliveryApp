//
//  ABCDeliveryToDepotNoteBringId.h
//  your-dpd
//
//  Created by Richard Simkins on 19/05/2015.
//  Copyright (c) 2015 dpd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ABCNotice.h"

@interface ABCDeliveryToDepotNoteBringId : ABCNotice
@end
